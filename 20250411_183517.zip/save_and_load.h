#include <filesystem>
#include <iostream>
#include <fstream>
#include "resources.h"

void save_score();
void get_name_and_score(std::vector<std::pair<std::string, int>>& score_list);