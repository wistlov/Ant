#include "music_and_sounds.h"

void background_music(){

    //PlaySound(TEXT("Music/Pokémon Center [Remix].wav"), NULL, SND_FILENAME | SND_SYNC);
}