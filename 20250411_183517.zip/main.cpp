#include "std_lib_facilities.h"
#include "AnimationWindow.h"
#include "GUI.h"
#include "game.h"
#include "ant.h"
#include "resources.h"

//------------------------------------------------------------------------------'

// C++ programs start by executing the function main
int main() {

    play_game();

    return 0;
}
//------------------------------------------------------------------------------
